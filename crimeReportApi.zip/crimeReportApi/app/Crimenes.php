<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crimenes extends Model
{
    //
}
